self.assetsManifest = {
  "version": "1Iy2fa1l",
  "assets": [
    {
      "hash": "sha256-KOVJ7sRBshbmRhKAKQF7tzN76mWHPiEkdq+JFvoVZuE=",
      "url": "MahjongInitialDraw.styles.css"
    },
    {
      "hash": "sha256-rXn2nJ4RnRjExCMNXQdJaFtoHJMxwRWshBSHLEGsgRo=",
      "url": "_framework/MahjongInitialDraw.vdyh6q5g7a.wasm"
    },
    {
      "hash": "sha256-v+uwBWlsF4iCHG6B9ZA8x3jlos/84zEJCWdcqZNu3Sk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.tx885whulx.wasm"
    },
    {
      "hash": "sha256-TMJrwxmh7raq50FXlf8OFb9/PXWC0dJ48IVhshQE3jE=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.ojjbeuchn6.wasm"
    },
    {
      "hash": "sha256-8ebObNDUZRTCKpFo4fm5X3/In3DhlvyYeuF85ZjhyfM=",
      "url": "_framework/Microsoft.AspNetCore.Components.nmyvcb4yd5.wasm"
    },
    {
      "hash": "sha256-yxPiW+l2bwpbqQMt+LqIVyoudbaoHWuYPnD4DDJUr88=",
      "url": "_framework/Microsoft.Extensions.Configuration.7p4o2tpul4.wasm"
    },
    {
      "hash": "sha256-Vaey6KNbQjvV5f4sgTb9Z7DpC7i8fKGaG8HGFaV0O8k=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.79qfazjlcu.wasm"
    },
    {
      "hash": "sha256-e7KqvUYccR78CImWVq5kLp49gK7pPVNLuAnrrJ59tXE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.lo1485j0el.wasm"
    },
    {
      "hash": "sha256-e8G0JQI0dUUudPzWdfamVDGrSV+tqr50McBL0FMtaGo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ynt3oix6u.wasm"
    },
    {
      "hash": "sha256-LKnHvE7JfYOuVH/otBseZKfzAUoBiKk4UcX6nQ+P+B0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.0t4ej5mr6g.wasm"
    },
    {
      "hash": "sha256-bhMyrU5Kmxq6U/Pm8Oj+c31HPzzV9IgKVwFK2lkpmO8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.6rwj86mmew.wasm"
    },
    {
      "hash": "sha256-Rw3p7P7cbetsRUa1O+Q7ltdFAmR7kf26guR3xO9aq3s=",
      "url": "_framework/Microsoft.Extensions.Logging.fugc9tzrx1.wasm"
    },
    {
      "hash": "sha256-aghFR5ix2EFcXsXxIjilRm2GirVLMF7NAkzXIR0Y9JY=",
      "url": "_framework/Microsoft.Extensions.Options.er9kaksr7l.wasm"
    },
    {
      "hash": "sha256-DnlMLnoUShENHHG/1JwJlFyv8wwJ0wNnr/fEV/sR2dI=",
      "url": "_framework/Microsoft.Extensions.Primitives.2jafe63jbt.wasm"
    },
    {
      "hash": "sha256-sGms9Oai1ztzgfMsqBvmeKwa5ZyGWr/AEXr6thw0lso=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.8eb000j8w7.wasm"
    },
    {
      "hash": "sha256-LuYfR4a5fwfclUwXPnTjZGpINIjF23AhCZmTFWP2xbQ=",
      "url": "_framework/Microsoft.JSInterop.iknej2zdh8.wasm"
    },
    {
      "hash": "sha256-SIeGJWhnB+5ZSqtStnV1xM9S27ECotCCXjDPV5AEOnc=",
      "url": "_framework/System.Collections.4p42vxm8yv.wasm"
    },
    {
      "hash": "sha256-61G6RdWky6wSKMoiBGmJfoebCUZviZ5ID5YVq4HzR40=",
      "url": "_framework/System.Collections.Concurrent.fzjfrdn2ak.wasm"
    },
    {
      "hash": "sha256-HtRM8z6SWCHMrKQrNZIALzy2FMivErM+NlMU8wP0mA4=",
      "url": "_framework/System.Collections.Immutable.2sznr7iy82.wasm"
    },
    {
      "hash": "sha256-NQkKskUXENdTSf2C0+y41sjKi68CHmUqCgPPLNxKyGw=",
      "url": "_framework/System.ComponentModel.h9eo79o86x.wasm"
    },
    {
      "hash": "sha256-fG5C33jvnQc30BhFHHcR3muFlB4tfYRR2x1XYylDdrM=",
      "url": "_framework/System.Console.ckimbfyjuj.wasm"
    },
    {
      "hash": "sha256-V5z9/XlJMVOFEDQ+R/mfLxmcykbKzh9+yhFeRdF4kdU=",
      "url": "_framework/System.IO.Pipelines.h68d94scrb.wasm"
    },
    {
      "hash": "sha256-UffGiVFyKIH/Pz+CNJglFQuQxoJdcVdR41MkGONAtRs=",
      "url": "_framework/System.Linq.3fh24cxoev.wasm"
    },
    {
      "hash": "sha256-SrBVMo6y8K0FW1a07/LPx+E73mNBQDIPA1+IPvft0aI=",
      "url": "_framework/System.Memory.acxyzgdz32.wasm"
    },
    {
      "hash": "sha256-JAE9AaKDVKxndwRZ1OskmjfSPR3izzJ0StYkztrZTBQ=",
      "url": "_framework/System.Net.Http.glm30nrgji.wasm"
    },
    {
      "hash": "sha256-6qfRgKqAwwmWzGgvzRHh01AJ7x6iBsgex62EJYI/owY=",
      "url": "_framework/System.Net.Primitives.64ga4lbdmv.wasm"
    },
    {
      "hash": "sha256-y/iJtGSWxjHNeGI1cE4DCizKflrVQ+jXvw29Km/P/tk=",
      "url": "_framework/System.Private.CoreLib.den7dmpj6v.wasm"
    },
    {
      "hash": "sha256-GKw5UglIavdJ+pv/5RP3KeP0+pUmf2KWkc3LjqO1s5o=",
      "url": "_framework/System.Private.Uri.8sqa29gs3n.wasm"
    },
    {
      "hash": "sha256-8PKecqqjpOU718h3g2COPpEnbIFUFxQydr+hZ33QyU4=",
      "url": "_framework/System.Runtime.0k67idnvax.wasm"
    },
    {
      "hash": "sha256-2nWN1zwezK82JRmcnLLcKzdroP7qZRNl6DW0r2jhKe4=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.2qzse51b5r.wasm"
    },
    {
      "hash": "sha256-gAQK1aO5MWD0GwIAc812qHpnec5wlHwgnyaZ9RGOUOg=",
      "url": "_framework/System.Text.Encodings.Web.4zpcd8unrt.wasm"
    },
    {
      "hash": "sha256-kNyMEodCkFLZWxbFozOTg+amSda8YN6Sjp9EN5xmbRA=",
      "url": "_framework/System.Text.Json.8iu0dnianz.wasm"
    },
    {
      "hash": "sha256-SKkTQL9D0Loskr+NX705/WITcRNb/8VQlQorMrz5S6M=",
      "url": "_framework/System.Text.RegularExpressions.0e9rlv7vxy.wasm"
    },
    {
      "hash": "sha256-JMQN1Jo7SV0/4W0kiV+Ep4ISRP9UePHr99FabrEKk0c=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-/pcrNUZIFxvVrfML8zazMdEZ+IB0TdSKqJ6mAPvV+w4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-jDoqNUBmeHUg1jXlLLDfrXIhta3n8OPQU16EWSehEz4=",
      "url": "_framework/dotnet.native.81y96s741n.wasm"
    },
    {
      "hash": "sha256-8guFukgpJowLt2W6jTUEA9JuCcRKPtWaU/KpoIOQt44=",
      "url": "_framework/dotnet.native.yovmyk9s6f.js"
    },
    {
      "hash": "sha256-82FoDmY+LsehdN2u8aSGEutGEKXJHcYaSX/3zptbsCw=",
      "url": "_framework/dotnet.runtime.tsg4gsv2hg.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-ByDEK6fBA5ybZYnphSmUzikhoqt6dpqDObpXX7sde9s=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-172nCzgY4gi8T6jCM8UQ+EPZojZZZSTeVU6u4XWqC1c=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-pbT48xKo7HfBY7mFhWKg9KHubfqfwF12mydOsL8hS+o=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-2h9MpiTDilxFnVMno7e1boLfZbVD3aptT3w0+Vn5zuY=",
      "url": "images/tiles/man1.png"
    },
    {
      "hash": "sha256-Ol4fP0VKJDwFodgar38j7KIKDqR00rFZvunPyjIAD9c=",
      "url": "images/tiles/man2.png"
    },
    {
      "hash": "sha256-y2y1OgY0smH6PIdDUji2hyItwilqu/syZElxvsD+swA=",
      "url": "images/tiles/man3.png"
    },
    {
      "hash": "sha256-Fp9gY3jM8GQtluEFMfyoKCkgK87uTPjlYNwFzp/hgdY=",
      "url": "images/tiles/man4.png"
    },
    {
      "hash": "sha256-B4XBs8/l3t0brq45RZDIzxkLCZEvl8R6RijMiyiW/o4=",
      "url": "images/tiles/man5-aka.png"
    },
    {
      "hash": "sha256-YltRIsBJBonzsgAP/ZWUo5wSWlH8cqzV3QidGKjsXi8=",
      "url": "images/tiles/man5.png"
    },
    {
      "hash": "sha256-YrYObwW3oNt4qmo4Qgyj1OVZmgMgJcEptASpExiSQgc=",
      "url": "images/tiles/man6.png"
    },
    {
      "hash": "sha256-gTbTUACM1n/QfP/QzNnNwr3WAF0rXFWtoHU9tzkgz9o=",
      "url": "images/tiles/man7.png"
    },
    {
      "hash": "sha256-G4bc2NgRa4QCeJLaioLZj16MDTuxFjOubITLfomgUKw=",
      "url": "images/tiles/man8.png"
    },
    {
      "hash": "sha256-ZvbaPpeh1zz2bdNK1OGFt0CYiZVCIy2KZYGz81Tje0c=",
      "url": "images/tiles/man9.png"
    },
    {
      "hash": "sha256-hosHEKnEDPQpgSKxgrBBx+O1BkF+rBw4UNYNRLs+J48=",
      "url": "images/tiles/pin1.png"
    },
    {
      "hash": "sha256-2mc2A60tiWT7tZ6dYH6Wzs+zOtLvkkQ88K+LWPhukTk=",
      "url": "images/tiles/pin2.png"
    },
    {
      "hash": "sha256-/F7BcB2cJlx8IdglSCSSUPoqsh0hUuGLaDqIB5T49D4=",
      "url": "images/tiles/pin3.png"
    },
    {
      "hash": "sha256-V8Xm8YlrUzuCjYFhimN4O10FqDi62TWl45c63hysus4=",
      "url": "images/tiles/pin4.png"
    },
    {
      "hash": "sha256-IH4DTs24ohSnMSXeKGUQZ/rgU6zKMpTgiy+jWX1TpyY=",
      "url": "images/tiles/pin5-aka.png"
    },
    {
      "hash": "sha256-u0dJ0ifqUv9x52NbA/smoLGP4XqJUtRxAN/x/H0pacA=",
      "url": "images/tiles/pin5.png"
    },
    {
      "hash": "sha256-/UbIASWWuMGHkC8SNc98av5TuyDoCk2XGzim8xt+8EM=",
      "url": "images/tiles/pin6.png"
    },
    {
      "hash": "sha256-vG+zuYpGH+GMi1NRsTFGR4NK7EkpcxpBqLkMjDIf/jk=",
      "url": "images/tiles/pin7.png"
    },
    {
      "hash": "sha256-aMnFaKIYSsLjN6HCgVvMlYzMJsUMxmclzkCJq40DtNQ=",
      "url": "images/tiles/pin8.png"
    },
    {
      "hash": "sha256-qEeA01V5kYK9mmt1S+5Tpix6ROgjjt3Ear8uFVPpsGQ=",
      "url": "images/tiles/pin9.png"
    },
    {
      "hash": "sha256-l33yUcvxO/1nMFBm0lEb48LrB3YQkDUNXCtYgZmaqCA=",
      "url": "images/tiles/sou1.png"
    },
    {
      "hash": "sha256-iKkqTOIa+gohZ45eRRsBKRpDXi6hmEAnelyL3e7tWX0=",
      "url": "images/tiles/sou2.png"
    },
    {
      "hash": "sha256-PPTrZR7dJQCAFRTWo3+D+Deu3fp5V1ZB3ol2rNAwnNQ=",
      "url": "images/tiles/sou3.png"
    },
    {
      "hash": "sha256-jIlFnhUWmfAp49crHSqLmX7ek8rQRg177pIaaVwH0eQ=",
      "url": "images/tiles/sou4.png"
    },
    {
      "hash": "sha256-z4ET9/CKeMFYTHQ7+/N4dVYwKuyvZD/6DFB6XFY7JaM=",
      "url": "images/tiles/sou5-aka.png"
    },
    {
      "hash": "sha256-4LozUurB+CkPH+bw9o0IzF1o81vUMr3pQ8cHQWQgf5w=",
      "url": "images/tiles/sou5.png"
    },
    {
      "hash": "sha256-OhmPbGex3XEXU5XUEIF+mNQnaNGMEa+JMILM/e9738w=",
      "url": "images/tiles/sou6.png"
    },
    {
      "hash": "sha256-bjOE7TY0XpvAJTqIRK72sDTgzPAaW5B/yjgL+6KP4TM=",
      "url": "images/tiles/sou7.png"
    },
    {
      "hash": "sha256-fmlndUGLHvfoV5CI4PQ//igCwTu5S5c1UCBOB4NuO18=",
      "url": "images/tiles/sou8.png"
    },
    {
      "hash": "sha256-X3a2g3kMSVftkW2V4iY8k3uWxVhGBiv/s+yvqWRsvy0=",
      "url": "images/tiles/sou9.png"
    },
    {
      "hash": "sha256-JZJcgQfhEhyECIQ+/qiqsv4nwpOq/schLUCyHbfXgNk=",
      "url": "images/tiles/ura-green.png"
    },
    {
      "hash": "sha256-rFaOmWVcMyMMO9iHIs9Ww2VqDZWdbJ7YMpLOIWQ8Y20=",
      "url": "images/tiles/zi1.png"
    },
    {
      "hash": "sha256-bU6K6+nq/z6/fqTY4bxXT7MYrWOrRcc471/PW9ujjO0=",
      "url": "images/tiles/zi2.png"
    },
    {
      "hash": "sha256-UHE2kLp6nw8MMtMFmyAl+hJ6h5x971+EMQZOWuyrYxw=",
      "url": "images/tiles/zi3.png"
    },
    {
      "hash": "sha256-iCplfDrKsFzOrTUCzQ7oOOVMXkLu/Fk6BUHK0OLPFSE=",
      "url": "images/tiles/zi4.png"
    },
    {
      "hash": "sha256-pJMn61S8JUS5Yrx2tvD2nA7zzz+aA656JahiRoFZ458=",
      "url": "images/tiles/zi5.png"
    },
    {
      "hash": "sha256-zXEKUm8SPUsuYWwodXd2o9QbBK6HJCtrBDIFLUxbL2A=",
      "url": "images/tiles/zi6.png"
    },
    {
      "hash": "sha256-mUTCSwjMra208hBKOTFnyfAG0tsIYe5ZSeF6CRRcYm4=",
      "url": "images/tiles/zi7.png"
    },
    {
      "hash": "sha256-Cj8D0W2iZeK0faPLWYRYzA4GsvQ5/nLguBCGF/NUdCI=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-5Q/lFVM2TpVkx2/7jBThQD+G5BwegHs3cMIyNpDv3N8=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-TWAe9Lt03j0VAdf6fYkuTk7x6LL5v19621hgmbrWl9A=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-0dbiVOxRiDk/iS4xwvylOZQ7If9tu5bmUuc48RSrWuk=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-E21hbYkmQ2Ec88yFKIIUYawooC2acQJEb8Ur8emxql0=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-sYD5x+fSuPzKWDiPZzo25QyvYj5qGEeaymHtq4wCAW8=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-y+bZ+XJOMaJrgRnrjsyFo6vD/zxvj4IM9+Cwro2j2UM=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-8WxkKay9OmeyRgw2a3e+tBxFv5zdiWvGNSl7rfMi2IQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-XecU4dFaiU8i9mP67BJ0Zl1eOXWko7YOT/BcaJjP2AE=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-VdhxGg8cktNBp5DC8FmRMP24nVKd37l9e8uzmD0ZSCM=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-Lpv+H807gYMIhj4OmkjwufZsyJn0EWdX1QATqlDAPr4=",
      "url": "manifest.webmanifest"
    }
  ]
};
